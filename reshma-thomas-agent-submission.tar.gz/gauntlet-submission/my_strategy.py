"""Reshma Thomas — Agent Gauntlet competitor strategy.

What this strategy changes vs. the starter kit:

1. Model selection     — scores every alias the proxy advertises (family strength,
                         parameter size, reasoning ability, time limit) instead of
                         taking roster order. Works on any roster; set
                         PREFERRED_MODEL_ORDER to pin exact aliases once we have
                         seen the real list.
2. Time-aware budget   — max_tokens scales with the puzzle's time limit so a
                         reasoning model cannot think past the deadline.
3. Logic-solver prompt — constraint-by-constraint solving and an exact,
                         format-faithful ANSWER line.
4. Verification pass   — when time allows, a second, different model re-checks
                         the draft against every rule and clue (see agent.py).
5. Image prompts       — edit: change only what is asked, preserve everything
                         else; generate: satisfy every stated constraint literally.
"""

from __future__ import annotations

import math
import os
import re
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext


# ---------------------------------------------------------------------------
# Model ranking
# ---------------------------------------------------------------------------

# Text models to try first, in order, when present on the roster. Measured with
# tools/model_bench.py on the Practice proxy (28 Oct 2026): all of the top nine
# solved 5/5 logic puzzles; ranked by speed and token use after correctness.
# Re-run `python tools/model_bench.py --apply` to refresh. The live event roster
# may differ: names not listed here fall back to the heuristic below.
PREFERRED_MODEL_ORDER: list[str] = ["gpt-5.6-terra", "nemotron-3-ultra", "gemini-3.6-flash", "gemini-3.8-flash", "qwen3.7-max", "nemotron-3.5-lightning", "qwen3.7-flash", "qwen3.7-plus", "qwen3.6-35b", "gpt-5.4", "nemotron-3-super"]

# Image models, best first, when present. Image quality is judged, so the
# strongest image model leads and the "lite" one is the last resort.
PREFERRED_IMAGE_MODEL_ORDER: list[str] = ["gemini-3-pro-image", "gemini-3.1-flash-image", "gemini-3.1-flash-lite-image"]

# Family keyword -> strength bonus for text reasoning. First match wins, so
# specific keywords come before general ones.
_FAMILY_BONUS: list[tuple[str, float]] = [
    ("gpt-5", 46.0),
    ("nemotron-3-ultra", 46.0),
    ("gemini-3", 42.0),
    ("qwen3.7", 40.0),
    ("qwen3.6", 26.0),
    ("nemotron-3", 38.0),
    ("nemotron-ultra", 46.0),
    ("gpt-oss-120b", 44.0),
    ("qwen3-235b", 43.0),
    ("deepseek-r1", 42.0),
    ("nemotron-super", 40.0),
    ("deepseek-v3", 40.0),
    ("kimi-k2", 40.0),
    ("glm-4.5", 38.0),
    ("deepseek", 36.0),
    ("qwen3", 36.0),
    ("gpt-oss", 34.0),
    ("qwq", 34.0),
    ("llama-3.1-405b", 34.0),
    ("llama-4-maverick", 34.0),
    ("glm", 32.0),
    ("llama-3.3-70b", 30.0),
    ("mistral-large", 30.0),
    ("nemotron-nano", 24.0),
    ("nemotron", 30.0),
    ("llama", 22.0),
    ("mistral", 20.0),
    ("gemma", 18.0),
    ("phi", 14.0),
]

# Aliases with these words are not text reasoners.
_TEXT_PENALTY_WORDS = (
    "image", "vision", "embed", "rerank", "guard", "safety", "reward",
    "tts", "whisper", "audio", "ocr", "clip",
)
_REASONING_WORDS = ("reason", "think", "r1", "qwq", "oss", "ultra", "super")
_TIER_BONUS: list[tuple[str, float]] = [
    ("ultra", 4.0), ("max", 4.0), ("pro", 4.0), ("terra", 4.0), ("plus", 2.0),
]
# "flash" is not here: on Practice the Gemini flash models were fast and accurate.
_SMALL_WORDS = ("mini", "nano", "small", "tiny", "lite")


def _param_billions(alias: str) -> float:
    """Parameter count from names like 'qwen3-32b', 'llama-3.1-405b', '8x22b'."""
    text = alias.lower()
    moe = re.search(r"(\d+)x(\d+(?:\.\d+)?)b", text)
    if moe:
        return float(moe.group(1)) * float(moe.group(2)) * 0.35
    sizes = [
        float(m)
        for m in re.findall(r"(?<![a-z\d.])(\d+(?:\.\d+)?)b(?![a-z])", text)
    ]
    return max(sizes) if sizes else 0.0


def score_image_model(alias: str) -> float:
    """Higher is better for image quality: pro > standard > lite."""
    name = alias.lower()
    score = 0.0
    if "pro" in name or "ultra" in name:
        score += 2.0
    if any(word in name for word in ("lite", "mini", "nano", "small")):
        score -= 2.0
    return score


def score_text_model(alias: str, time_limit_s: float = 120.0) -> float:
    """Higher is better: raw strength balanced against the puzzle clock."""
    name = alias.lower()
    if any(word in name for word in _TEXT_PENALTY_WORDS):
        return -100.0

    score = 10.0
    for keyword, bonus in _FAMILY_BONUS:
        if keyword in name:
            score += bonus
            break

    size = _param_billions(name)
    if size:
        score += 10.0 * math.log10(1.0 + size)  # 8b≈+9, 70b≈+18, 400b≈+26
    if any(word in name for word in _REASONING_WORDS):
        score += 4.0
    for word, bonus in _TIER_BONUS:
        if word in name:
            score += bonus
            break

    tight_clock = bool(time_limit_s) and time_limit_s <= 60
    if tight_clock and size > 200:
        score -= 8.0  # huge models may not finish in 60 s
    if any(word in name for word in _SMALL_WORDS):
        score -= 3.0 if tight_clock else 6.0
    return score


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_TEXT_SYSTEM_PROMPT = (
    "You are a meticulous puzzle and reasoning solver competing in a timed arena. "
    "Accuracy and exact output format matter most.\n"
    "Method:\n"
    "1. Identify exactly what is asked and the required answer format.\n"
    "2. List every constraint from the description, rules and clues.\n"
    "3. Solve systematically: deduce, eliminate, or enumerate cases.\n"
    "4. Check your candidate against EVERY constraint; fix anything that fails.\n"
    "Output: the first line of your reply must be exactly\n"
    "ANSWER: <final answer>\n"
    "The answer must match the requested format exactly (casing, order, "
    "separators, units, number of items) with no extra words. After the ANSWER "
    "line you may add at most two short justification lines. Do not output "
    "<think> tags. Never answer 'unknown'; give your single best answer."
)

_VERIFY_SYSTEM_PROMPT = (
    "You are a strict answer checker for a timed puzzle arena. You receive a "
    "puzzle and a proposed answer. Check the proposed answer against every rule, "
    "every clue and the required output format. If it is fully correct, repeat "
    "it unchanged. If anything is wrong, solve the puzzle again and give the "
    "corrected answer.\n"
    "The first line of your reply must be exactly: ANSWER: <final answer>\n"
    "Then one short line: VERDICT: confirmed  or  VERDICT: corrected"
)


class MyStrategy(BaseStrategy):
    """Reshma Thomas — Agent Gauntlet strategy."""

    # Team identity. AGENT_ID / AGENT_NAME from the environment override these.
    agent_id = "reshma-thomas-agent"
    agent_name = "Reshma Thomas"

    text_system_prompt = _TEXT_SYSTEM_PROMPT
    text_strategy_notes = "Constraint-by-constraint solving with a verification pass."
    text_temperature = 0.0
    text_max_tokens = 8192

    # Verification pass (called from examples/python_simple/agent.py).
    verify_enabled = True
    verify_min_remaining_s = 25.0     # never verify with less than this left
    verify_min_remaining_frac = 0.40  # ...or with less than 40% of the clock left
    verify_skip_difficulties = ("easy",)

    image_strategy_notes = (
        "Edit: change only what is requested and preserve the rest. Generate: "
        "satisfy every constraint literally. Standard resolution only."
    )

    # ---- model choice -----------------------------------------------------

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(available_models) or list(available_models)
            # For comparison runs: set AGENT_IMAGE_MODEL=<alias> to try a model first.
            override = os.environ.get("AGENT_IMAGE_MODEL", "").strip()
            order = ([override] if override else []) + PREFERRED_IMAGE_MODEL_ORDER
            pinned = list(dict.fromkeys(m for m in order if m in image_models))
            rest = sorted(
                (m for m in image_models if m not in pinned),
                key=lambda m: (-score_image_model(m), image_models.index(m)),
            )
            return pinned + rest

        roster = [m for m in available_models if str(m).strip()]
        pinned = [m for m in PREFERRED_MODEL_ORDER if m in roster]
        time_limit = float(ctx.max_time_s or 120)
        rest = sorted(
            (m for m in roster if m not in pinned),
            key=lambda m: (-score_text_model(m, time_limit), roster.index(m)),
        )
        return pinned + rest

    def pick_model(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> str:
        _ = ctx
        if not ranked_models:
            return ""
        # Verify with the #2 model: on Practice it was as accurate as #1 (5/5), and
        # a different model family catches mistakes the first one would repeat.
        # Never verify with a model outside the benchmarked top tier.
        if stage == "verify" and len(ranked_models) > 1:
            second = ranked_models[1]
            top_tier = PREFERRED_MODEL_ORDER[:5]
            if second in top_tier or not any(m in top_tier for m in ranked_models):
                return second
        return ranked_models[0]

    # ---- text prompts -----------------------------------------------------

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        clues = [str(c).strip() for c in ctx.clues if str(c).strip()]
        clue_block = "\n".join(f"{i}. {c}" for i, c in enumerate(clues, 1)) or "(none)"
        return (
            f"PUZZLE TYPE: {ctx.challenge_type.strip() or 'text'}\n\n"
            f"DESCRIPTION:\n{ctx.description.strip() or '(none)'}\n\n"
            f"RULES / REQUIRED FORMAT:\n{ctx.rules.strip() or '(none)'}\n\n"
            f"CLUES:\n{clue_block}\n\n"
            "Solve it using every clue. Check your answer against each clue before "
            "replying. First line exactly: ANSWER: <final answer>"
        )

    def build_verify_system_prompt(self, ctx: ChallengeContext) -> str:
        _ = ctx
        return _VERIFY_SYSTEM_PROMPT

    def build_verify_prompt(self, ctx: ChallengeContext, draft_answer: str) -> str:
        return (
            f"{self.build_solver_prompt(ctx)}\n\n"
            f"PROPOSED ANSWER: {draft_answer}\n\n"
            "Check the proposed answer against every clue and the required format."
        )

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        # ~70 generated tokens per second of clock, floor 3072, cap 8192.
        limit = float(ctx.max_time_s or 0)
        max_tokens = int(self.text_max_tokens)
        if limit > 0:
            max_tokens = max(3072, min(max_tokens, int(limit * 70)))
        return {"temperature": float(self.text_temperature), "max_tokens": max_tokens}

    def should_verify(self, answer: str, ctx: ChallengeContext) -> bool:
        if not self.verify_enabled or not answer.strip():
            return False
        # Practice (28 Oct): on easy puzzles the top model was right every time
        # and the check cost ~8 s, about 2 final points of speed. Verify only
        # medium, hard and unlabelled puzzles, where a wrong answer costs 70.
        if ctx.difficulty in self.verify_skip_difficulties:
            return False
        remaining = float(ctx.time_remaining_s or 0)
        limit = float(ctx.max_time_s or 0)
        if remaining < self.verify_min_remaining_s:
            return False
        if limit and remaining < limit * self.verify_min_remaining_frac:
            return False
        return True

    # ---- image prompts ----------------------------------------------------

    def plan_image_tool(self, ctx: ChallengeContext, available_tools: list[str]) -> str:
        if ctx.image_url and "image_edit" in available_tools:
            return "image_edit"
        if "image_generate" in available_tools:
            return "image_generate"
        return super().plan_image_tool(ctx, available_tools)

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        base = super().build_image_prompt(ctx)
        if ctx.image_url:
            guidance = (
                "Editing rules: apply ONLY the change requested above. Keep everything "
                "else identical to the input image: composition, framing, subject "
                "identity, pose, background, lighting, colours and style. Make the "
                "requested change clearly visible and naturally blended. Do not add "
                "text, watermarks, borders or extra objects unless asked."
            )
        else:
            guidance = (
                "Generation rules: include every element the prompt asks for exactly "
                "as described (count, colour, position, style). Respect every stated "
                "constraint literally; for example, 'no text' means no letters at all. "
                "Clean, well-lit, coherent composition; no watermarks or borders."
            )
        return f"{base}\n\n{guidance}"